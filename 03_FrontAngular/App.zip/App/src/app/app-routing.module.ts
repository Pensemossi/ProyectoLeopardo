import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginMasterComponent } from './Vista/COMMON/login-master/login-master.component';
import { SignupComponent } from './Vista/Login/SignUp/signup.component';
import { SigninComponent } from './Vista/Login/SignIn/signin.component';

import { NavComponent } from './Vista/COMMON/nav-master/nav.component';
import { AuthGuard } from './Servicio/Autenticación/auth.guard';

import { PreguntasComponent } from './Vista/preguntas/preguntas.component';
import { IndicadoresComponent } from './Vista/indicadores/indicadores.component';
import {CrearPreguntaComponent} from './Vista/crear-pregunta/crear-pregunta.component';

export const routes: Routes = [
  // Routing paginas 

  { path: 'login' , component : LoginMasterComponent, children : [{path: '', component: SigninComponent}]},
  { path: 'signup' , component : LoginMasterComponent,children : [{path: '', component: SignupComponent, data : {animation : 'isLeft'}}]},
  {path  : 'PreguntasFrecuentes' , component : PreguntasComponent , canActivate:[AuthGuard], },
  {path : 'Indicadores' , component : IndicadoresComponent},
  {path : 'CrearPregunta' , component : CrearPreguntaComponent},
  {path : '' ,redirectTo : '/login' , pathMatch: 'full'},

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

export class User {
    registro: string;
    Clave: string;
    Nombres : string;
    esAdministrador: string;

 
}
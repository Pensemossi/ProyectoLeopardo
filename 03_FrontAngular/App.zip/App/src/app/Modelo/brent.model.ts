export class Brent {
    price: number;
    created_at: Date;        

 
}
export class Accion {
    latestPrice: number;
    latestUpdate: Date;        

 
}
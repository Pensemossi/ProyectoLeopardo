export class Temperatura {
    temperatura : number;
} 
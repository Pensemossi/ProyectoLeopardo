export class Categoria {
    id : number
    nombre : string;
}   
  
export class Filtro {
    id : number;
    filtro : string;
}  
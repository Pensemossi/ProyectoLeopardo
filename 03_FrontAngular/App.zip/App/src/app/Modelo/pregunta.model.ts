export class Pregunta {
    id? : number;
    categoriaid : number;
    pregunta : string ; 
    respuesta : string ; 
    activa : string ; 
} 
export class PreguntaDto {
    categoriaid : number;
    pregunta : string ; 
    respuesta : string ; 
    activa : string ; 
} 
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class URLService {

  constructor() { }
  readonly rootUrl = " http://185.50.185.38:8090/api";
  readonly localUrl = "https://localhost:5001/api";
}

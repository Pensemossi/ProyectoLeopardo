import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'letras'
})
export class LetrasPipe implements PipeTransform {

  transform(value: number): String {
    if(value === 0){
        return 'Creado';
    } else if(value === -1){
      return 'Cancelado';
    } else if (value === 1 ){
      return 'Aprobado';

    } else if (value ===2){
      return 'Cancelado';
    }
}

}

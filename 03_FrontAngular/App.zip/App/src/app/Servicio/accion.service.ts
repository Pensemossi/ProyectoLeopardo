import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Accion} from '../Modelo/accion.model';
import {URLService} from './Common/url.service';
import { map } from 'rxjs/operators';
import { Categoria } from '../Modelo/categoria.model';
@Injectable({
  providedIn: 'root'
})
export class AccionService {

 public vectoraccion : Accion[];
  constructor( private http : HttpClient, private url : URLService) { }

  ObtenerAccion(){
    
    var  token = JSON.parse(localStorage.getItem('Token')); 
    let header = new HttpHeaders()
        .set('Accept' , 'application/json')
        .set('Usuario' , token.registro)
        .set('Token' , token.token);
        
  return this.http.get<Accion>(this.url.localUrl + '/accion',  { headers : header , responseType : 'json'})
  .pipe(map(data => data));
   // this.vectoraccion.push(this.accion);
    
  }
  
  

}

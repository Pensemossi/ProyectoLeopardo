import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, RouterStateSnapshot, CanActivate, Router } from '@angular/router';
import { Observable } from 'rxjs';

@Injectable()
export class AuthGuard implements CanActivate {
  constructor(private router: Router){ }
  canActivate(
    _next : ActivatedRouteSnapshot,
    _state : RouterStateSnapshot):boolean{
    if (localStorage.getItem('Token') != null)
    return true;
    this.router.navigate(['/login']);
    return false;
    }

    
    
  
}

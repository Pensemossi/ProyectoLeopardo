import { Injectable } from '@angular/core';
import {Pregunta, PreguntaDto} from '../Modelo/pregunta.model';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import {URLService} from './Common/url.service';

@Injectable({
  providedIn: 'root'
})
export class PreguntaService {
  formData: Pregunta;
  formdata1 : Pregunta;
  formdataDTO : PreguntaDto;
  pregunta : Pregunta[];
  constructor(private http: HttpClient , private url : URLService) { }

  PostPregunta(formData : Pregunta){
    var  token = JSON.parse(localStorage.getItem('Token')); 
    let header = new HttpHeaders()
        .set('Accept' , 'application/json')
        .set('Usuario' , token.registro)
        .set('Token' , token.token);
        
        formData.activa = "S";

    return this.http.post(this.url.localUrl  + '/pregunta', formData , {headers : header });
  }
  mostrarpregunta(){
   var id = localStorage.getItem('id' );
    var pregunta = localStorage.getItem('pregunta');
    var respuesta = localStorage.getItem('respuesta'  );
    var categoriaid = localStorage.getItem('categoriaid'  );
   var activa =  localStorage.getItem('activa'  );

  }
  ObtenerPreguntas(){
    
    var  token = JSON.parse(localStorage.getItem('Token')); 
    let header = new HttpHeaders()
        .set('Accept' , 'application/json')
        .set('Usuario' , token.registro)
        .set('Token' , token.token);
        
  this.http.get(this.url.localUrl + '/pregunta',  { headers : header , responseType : 'json'} )
    .toPromise().then(res => this.pregunta = res as Pregunta[]);
    
  }

  Update(formData : Pregunta){
    var  token = JSON.parse(localStorage.getItem('Token')); 
    let header = new HttpHeaders()
        .set('Accept' , 'application/json')
        .set('Usuario' , token.registro)
        .set('Token' , token.token);

    return this.http.put(this.url.localUrl  + '/pregunta/' + formData.id , formData , {headers : header });
  }

}

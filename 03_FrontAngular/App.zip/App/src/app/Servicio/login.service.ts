import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { User } from '../Modelo/login.model';
import { tap, map } from 'rxjs/operators';
import { Observable } from "rxjs/internal/Observable";
import { isNullOrUndefined } from 'util';
import { Local } from 'protractor/built/driverProviders';
import {URLService} from './Common/url.service';

@Injectable({
  providedIn: 'root'
})

export class LoginService {
  list : User[];
  data: string;
  
  constructor(private http: HttpClient , private url : URLService) { }
  

  userAuthentication(usuario: string,clave : string ){
    var request = new HttpHeaders({
      'Content-Type':  'application/json',
      'Authorization': 'Basic ' + btoa(usuario + ':' + clave  )});
    return this.http.post<User>(this.url.localUrl + '/Auth  ','',{headers: request}).pipe(map(data => data));
     
  }
  setUser(usuario : User) : void{
    let user_string  = JSON.stringify(usuario);
    localStorage.setItem('Token', user_string);
  }
  setUsuario(Token) : void {
    let token = JSON.stringify(Token);
   localStorage.setItem('Token', token);

    
  }


  getToken(){
   return localStorage.getItem('Token');
  }

  

    
}

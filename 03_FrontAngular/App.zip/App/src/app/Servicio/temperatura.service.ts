import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { URLService } from './Common/url.service';
import { map } from 'rxjs/operators';
import { Temperatura } from '../Modelo/temperatura.model';

@Injectable({
  providedIn: 'root'
})
export class TemperaturaService {
  
  constructor(private http : HttpClient, private url : URLService) { }
  ObtenerTemperatura(){
    var lat1 : string = localStorage.getItem('Lat');
    var lon1 : string = localStorage.getItem('Lon');
    var  token = JSON.parse(localStorage.getItem('Token')); 
    
    let header = new HttpHeaders()
        .set('Accept' , 'application/json')
        .set('Usuario' , token.registro)
        .set('Token' , token.token)
        .set('Lat' , lat1.replace('.' , ','))
        .set('Lon' , lon1.replace('.' , ','));

        
  return this.http.get<Temperatura>(this.url.localUrl + '/temperatura',  { headers : header , responseType : 'json'})
  .pipe(map(data => data));
   // this.vectoraccion.push(this.accion);
    
  }
}

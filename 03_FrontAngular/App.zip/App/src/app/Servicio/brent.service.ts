import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Brent} from '../Modelo/brent.model';
import { map } from 'rxjs/operators';
import {URLService} from './Common/url.service';
@Injectable({
  providedIn: 'root'
})
export class BrentService {

  constructor(private http : HttpClient, private url : URLService) { }
  ObtenerBrent(){
    
    var  token = JSON.parse(localStorage.getItem('Token')); 
    let header = new HttpHeaders()
        .set('Accept' , 'application/json')
        .set('Usuario' , token.registro)
        .set('Token' , token.token);
        
  return this.http.get<Brent>(this.url.localUrl + '/brent',  { headers : header , responseType : 'json'})
  .pipe(map(data => data));
   // this.vectoraccion.push(this.accion);
    
  }
}

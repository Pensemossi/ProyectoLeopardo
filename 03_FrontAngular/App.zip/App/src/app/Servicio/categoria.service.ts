import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Categoria} from '../Modelo/categoria.model';
import {Pregunta } from '../Modelo/pregunta.model';
import {URLService} from './Common/url.service';
@Injectable({
  providedIn: 'root'
})
export class CategoriaService {
  categoria : Categoria[];
  pregunta : Pregunta[];
  formdatas : Pregunta;
    formdata : Pregunta; 
  constructor(private http: HttpClient ,private url : URLService ) { 
    
  }
  ObtenerCategoria(){
    
    var  token = JSON.parse(localStorage.getItem('Token')); 
    let header = new HttpHeaders()
        .set('Accept' , 'application/json')
        .set('Usuario' , token.registro)
        .set('Token' , token.token);
        
  this.http.get(this.url.localUrl + '/categoria',  { headers : header , responseType : 'json'} )
    .toPromise().then(res => this.categoria = res as Categoria[]);
    
  }
  ObtenerPreguntas(){
    
    var  token = JSON.parse(localStorage.getItem('Token')); 
    let header = new HttpHeaders()
        .set('Accept' , 'application/json')
        .set('Usuario' , token.registro)
        .set('Token' , token.token);
        
  this.http.get(this.url.localUrl + '/pregunta',  { headers : header , responseType : 'json'} )
    .toPromise().then(res => this.pregunta = res as Pregunta[]);
    
  }

  Update(formData : Pregunta){
    var  token = JSON.parse(localStorage.getItem('Token')); 
    let header = new HttpHeaders()
        .set('Accept' , 'application/json')
        .set('Usuario' , token.registro)
        .set('Token' , token.token);

    return this.http.put(this.url.localUrl  + '/pregunta/' + formData.id , formData , {headers : header });
  }
}

import { BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule, enableProdMode } from '@angular/core';
import { RouterModule} from '@angular/router';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { SigninComponent } from './Vista/Login/SignIn/signin.component';
import { SignupComponent } from './Vista/Login/SignUp/signup.component';
import { LoginMasterComponent } from './Vista/COMMON/login-master/login-master.component';
import {routes} from './app-routing.module';
import { ToastrModule } from 'ngx-toastr';
import { HttpClientModule } from '@angular/common/http';
import {FormsModule} from '@angular/forms';
import { LayoutModule } from '@angular/cdk/layout';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatButtonModule } from '@angular/material/button';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatIconModule } from '@angular/material/icon';
import { MatListModule } from '@angular/material/list';
import {MatInputModule} from '@angular/material/input';
import {  ReactiveFormsModule } from '@angular/forms';
import { MatCardModule, MatNativeDateModule } from '@angular/material';
import {MatTabsModule} from '@angular/material/tabs';

import { NavComponent } from  './Vista/COMMON/nav-master/nav.component';
import { MzSidenavModule } from 'ngx-materialize';

import { LoginService } from './Servicio/login.service';
import { AuthGuard } from './Servicio/Autenticación/auth.guard';
import { DatepickerModule, BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { NgbModule , } from '@ng-bootstrap/ng-bootstrap';
import { AccordionModule } from 'ngx-bootstrap/accordion';
import { LetrasPipe } from './Servicio/Common/letras.pipe';

import { PreguntasComponent } from './Vista/preguntas/preguntas.component';
import {MatExpansionModule} from '@angular/material/expansion';
import { IndicadoresComponent } from './Vista/indicadores/indicadores.component';
import { CrearPreguntaComponent } from './Vista/crear-pregunta/crear-pregunta.component';

enableProdMode();
@NgModule({
  declarations: [
    AppComponent,
    SigninComponent,
    SignupComponent,
    NavComponent,
    LetrasPipe,
    LoginMasterComponent,
    PreguntasComponent,
    IndicadoresComponent,
    CrearPreguntaComponent
    
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    HttpClientModule,
    ToastrModule.forRoot(),
    RouterModule.forRoot(routes),
    LayoutModule,
    MatToolbarModule,
    MatButtonModule,
    MatSidenavModule,
    MatIconModule,
    MatListModule,
    MatCardModule,
    MatTabsModule,
    MatInputModule,
    ReactiveFormsModule,
    MzSidenavModule,
    NgbModule ,
    MatNativeDateModule,
    AccordionModule.forRoot(),
    BsDatepickerModule.forRoot(),
    DatepickerModule.forRoot() ,
    MatExpansionModule
  ],
 
  providers: [LoginService, AuthGuard, ],
  bootstrap: [AppComponent]
})
export class AppModule { }

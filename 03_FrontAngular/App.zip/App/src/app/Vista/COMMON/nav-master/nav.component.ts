import { Component, OnInit } from '@angular/core';
import { Router, RouterOutlet } from '@angular/router';
import {slider} from '../login-master/animations'; 

@Component({
  selector: 'app-nav',
  templateUrl: './nav.component.html',
  styleUrls: ['./nav.component.css'],
  animations : [slider]
})
export class NavComponent implements OnInit {

  constructor(private router : Router) { }

  ngOnInit() {
    
  }
    prepareRoute(outlet : RouterOutlet){
      return outlet && outlet.activatedRouteData && outlet.activatedRouteData['animation'];
    }
    Logout(){
      localStorage.removeItem('Token');
      this.router.navigate(['/login']);
    }
   
}

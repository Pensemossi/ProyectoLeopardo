import { Component, OnInit } from '@angular/core';
import { CategoriaService } from '../../Servicio/categoria.service';
import { AccionService} from '../../Servicio/accion.service';
import {  Categoria} from '../../Modelo/categoria.model';
import { Observable, from } from 'rxjs';
import { find } from 'rxjs/operators';
import { PreguntaDto, Pregunta } from '../../Modelo/pregunta.model';
import { PreguntaService } from 'src/app/Servicio/pregunta.service';
import { NgForm } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';
@Component({
  selector: 'app-preguntas',
  templateUrl: './preguntas.component.html',
  styleUrls: ['./preguntas.component.css']
})
export class PreguntasComponent implements OnInit {
  panelOpenState = false;
  public user ;
  preguntamodal: string;
  respuestamodal : string;
  activomodal : string;
  idmodal: number;
  constructor(private categoria : CategoriaService, 
     private preguntaService : PreguntaService ,
      private toastr : ToastrService,
      private update : PreguntaService,
      private router : Router) { }
  
  ngOnInit() {
    this.categoria.ObtenerCategoria();
    this.preguntaService.ObtenerPreguntas();

    this.user = JSON.parse(localStorage.getItem('Token'));
    
  }
  
  public preguntarActual : Pregunta; 
  EditarPreguntar(id, pregunta , respuesta, categoriaid,activa){
    if(this.user.esAdministrador == "N"){
      alert("No está autorizado");
      this.router.navigate(['/Indicadores']);
    }
    localStorage.setItem('id' , id);
    localStorage.setItem('pregunta' , pregunta);
    localStorage.setItem('respuesta' , respuesta);
    localStorage.setItem('categoriaid' , categoriaid);
    localStorage.setItem('activa' , activa);
    this.idmodal = id;
    this.preguntamodal = pregunta; 
    this.respuestamodal = respuesta;
    this.activomodal = categoriaid;
    this.preguntaService.mostrarpregunta();
    this.update.Update(id);

  }
  
  Modificar(idmodal, preguntamodal,respuestamodal){
    alert(idmodal);
    alert(preguntamodal);
    alert(respuestamodal);

    
    //this.preguntaService.Update(idmodal,preguntamodal,respuestamodal);
  }  


}

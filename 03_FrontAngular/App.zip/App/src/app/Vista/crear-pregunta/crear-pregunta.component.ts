import { Component, OnInit } from '@angular/core';
import { CategoriaService } from '../../Servicio/categoria.service';
import { ToastrService } from 'ngx-toastr';
import { NgForm } from '@angular/forms';
import { PreguntaService } from 'src/app/Servicio/pregunta.service';
import { Router } from '@angular/router';
import { format } from 'path';
import { Pregunta } from 'src/app/Modelo/pregunta.model';
@Component({
  selector: 'app-crear-pregunta',
  templateUrl: './crear-pregunta.component.html',
  styleUrls: ['./crear-pregunta.component.css']
})
export class CrearPreguntaComponent implements OnInit {
  public user ; 
  constructor(private preguntaService : PreguntaService , private categoria : CategoriaService,
     private toastr : ToastrService,
     private router : Router) { }

  ngOnInit() {

    this.resetForm();
    this.categoria.ObtenerCategoria();
    this.preguntaService.ObtenerPreguntas();
    this.user = JSON.parse(localStorage.getItem('Token')); 
    if(this.user.esAdministrador == "N"){
      alert("No esta autorizado");
      this.router.navigate(['/Indicadores']);
      
    }
  }
  resetForm(form? : NgForm){
    if(form != null)
      form.resetForm();
      this.preguntaService.formData = {
        id : null,
        categoriaid : null,
        pregunta : '',
        respuesta : '',
        activa :''

      }

  }
  onSubmit(form : NgForm){
    if(form.value.id == null)
    this.insertForm(form);
    else
    this.updateRecord(form);
  }

  insertForm(form : NgForm){
    this.preguntaService.PostPregunta(form.value).subscribe(res =>{  
       this.toastr.success('Pregunta Registrada Correctamente', 'PSI');
        this.resetForm(form);
      this.preguntaService.ObtenerPreguntas();
    },
    err => { 
      alert("error"); 
      alert(err);
    }
    )
  
    
}
populateForm(emp: Pregunta) {
  this.preguntaService.formdata1 = Object.assign({}, emp);
}
updateRecord(form: NgForm) {
  this.preguntaService.Update(form.value).subscribe(res => {
    this.toastr.info('Updated successfully', 'EMP. Register');
    this.resetForm(form);
    this.preguntaService.ObtenerPreguntas();
  });
}
}
import { Component, OnInit } from '@angular/core';
import { HttpErrorResponse, HttpClient, HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';
import { LoginService } from '../../../Servicio/login.service';

import { User } from '../../../Modelo/login.model';

@Component({
  selector: 'app-signin',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.css']
})
export class SigninComponent implements OnInit {
  Loading = false;
  isLoginError: boolean = false;
  constructor(  private userService : LoginService  , private router : Router,) { }
  
  ngOnInit() {
    
  }
  onSubmit(usuario,clave){
    this.Loading = true;
    this.userService.userAuthentication(usuario,clave).subscribe((res : any ) =>{
    const token =  res; 
    this.userService.setUsuario(token)
    this.router.navigate(['/Indicadores']);
    
    },
    (err : HttpErrorResponse)=>{
      this.isLoginError = true;
      this.Loading = false;
     
    })
    
  }
}

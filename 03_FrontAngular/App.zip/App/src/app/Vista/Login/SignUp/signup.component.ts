import { Component, OnInit } from '@angular/core';
import { User} from '../../../Modelo/login.model';
import { LoginService } from '../../../Servicio/login.service';
import { ToastrService} from 'ngx-toastr';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';


@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  
  registerForm: FormGroup;
  submitted = false;
  returnUrl: string;
  
  emailPatter = "^[a-z0-9.%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$";
  constructor(private userService: LoginService,
     private toastr: ToastrService, 
      private formBuilder: FormBuilder, 
      private route: ActivatedRoute,
     ) { }

  ngOnInit() {
    
    this.registerForm = this.formBuilder.group({
      username: ['', Validators.required],
      password: ['', Validators.required],
      email : ['', Validators.required]
     
  });
  this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/';
}


  get f() { return this.registerForm.controls; }
  }

 
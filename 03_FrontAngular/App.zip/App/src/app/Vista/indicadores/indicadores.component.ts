import { Component, OnInit } from '@angular/core';
import {AccionService} from '../../Servicio/accion.service';
import { HttpErrorResponse } from '@angular/common/http';
import { BrentService } from 'src/app/Servicio/brent.service';
import { TemperaturaService } from 'src/app/Servicio/temperatura.service';
@Component({
  selector: 'app-indicadores',
  templateUrl: './indicadores.component.html',
  styleUrls: ['./indicadores.component.css']
})
export class IndicadoresComponent implements OnInit {
  location = {};
  setPosition(position){
   
     this.location = position.coords;
    localStorage.setItem('Lat' , position.coords.latitude);
    localStorage.setItem('Lon', position.coords.longitude);
  }
  public user;
  public miaccion;
  public mibrent;
  public mitemperatura ; 
  date ; 
  constructor(private accion : AccionService , private brent : BrentService, private temperatura : TemperaturaService) { }

  ngOnInit() {
    if(navigator.geolocation){
      navigator.geolocation.getCurrentPosition(this.setPosition.bind(this));
      };
    this.accion.ObtenerAccion();
    this.brent.ObtenerBrent();
   
   this.temperatura.ObtenerTemperatura();
    this.accion.ObtenerAccion().subscribe((res : any ) =>{
      this.miaccion = res ; 
      
 
      
      },
      (err : HttpErrorResponse)=>{
       
       alert("error");
       
      });
      this.brent.ObtenerBrent().subscribe((res : any ) =>{
        this.mibrent = res ; 
      
    
        
        },
        (err : HttpErrorResponse)=>{
         
         alert("error");
         
        });
     
        this.temperatura.ObtenerTemperatura().subscribe((res : any ) =>{
          this.mitemperatura = res ; 
        
      
          
          },
          (err : HttpErrorResponse)=>{
           
           alert("error");
           
          });
      this.date = new Date();
    this.user = JSON.parse(localStorage.getItem('Token')); 
  }

}
